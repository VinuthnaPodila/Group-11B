<!-- Include Header -->
<?php include("./header.php"); ?>

<!-- !PAGE CONTENT! -->
<div class="w3-main" style="margin-left:300px;margin-right:40px">

    <!-- Header -->
    <div class="w3-container" style="margin-top:50px" id="showcase">
        <h1 class="w3-jumbo"><b>Drone Delivery Management</b></h1>
        <h1 class="w3-xxxlarge w3-text-red"><b>Explore our Solutions.</b></h1>
        <hr style="width:50px;border:5px solid red" class="w3-round">
    </div>

    <!-- Photo grid (modal) -->
    <div class="w3-row-padding">
        <div class="w3-half d-flex">
            <img src="./IMG/homebg1.jpg" style="width:100%;max-width:300px;height:auto;max-height:400px"
                onclick="onClick(this)" alt="Efficient Route Planning">
            <img src="./IMG/homebg3.jpeg" style="width:100%;max-width:300px;height:auto;max-height:400px"
                onclick="onClick(this)" alt="Automated Parcel Handling">
            <img src="./IMG/homebg2.avif" style="width:100%;max-width:300px;height:auto;max-height:400px"
                onclick="onClick(this)" alt="Secure Delivery Solutions">
            <img src="./IMG/homebg4.jpeg" style="width:100%;max-width:300px;height:auto;max-height:400px"
                onclick="onClick(this)" alt="Optimized Logistics">
        </div>
    </div>


    <!-- Modal for full size images on click-->
    <div id="modal01" class="w3-modal w3-black" style="padding-top:0" onclick="this.style.display='none'">
        <span class="w3-button w3-black w3-xxlarge w3-display-topright">×</span>
        <div class="w3-modal-content w3-animate-zoom w3-center w3-transparent w3-padding-64">
            <img id="img01" class="w3-image">
            <p id="caption"></p>
        </div>
    </div>

    <!-- Services -->
    <div class="w3-container" id="services" style="margin-top:75px">
        <h1 class="w3-xxlarge w3-text-red"><b>OUR SERVICES</b></h1>
        <hr style="width:50px;border:5px solid red" class="w3-round">
        <p>The Drone Delivery Management System simplifies the process of transporting essential medical supplies,
            including blood, medical kits, and drugs, to hospitals worldwide through third-party drone companies.
            Our platform introduces an overnight delivery feature, crucial for sending urgent documents and items.
        </p>
        <p>We've developed a Quote Generator, offering users precise pricing, distance estimation, and expected
            delivery time for both regular and overnight shipments. This tool empowers customers to understand costs
            upfront, facilitating comparisons with other drone delivery services before making a payment.</p>
        <p>The system offers:</p>
        <ul>
            <li><strong>User Registration and Authentication:</strong> Secure registration and login for authorized
                access.</li>
            <li><strong>Dashboard:</strong> A user-friendly interface displaying past, pending, and delivery
                history.</li>
            <li><strong>Order Placement:</strong> Effortless ordering for medical supplies and documents.</li>
            <li><strong>Quote Generator:</strong> Accurate price estimation based on distance, weight, and delivery
                type.</li>
            <li><strong>Communication and Notifications:</strong> Updates on order status and delivery information.
            </li>
            <li><strong>Feedback and Rating System:</strong> User feedback for service improvement and
                trust-building.</li>
        </ul>
        <p>This platform leverages drone technology, enabling stable vertical flight for monitoring and delivery
            purposes. Drones significantly reduce transportation time and costs, especially in the delivery of
            urgent medical supplies. Our system ensures global distribution of vital medical resources, enhancing
            efficiency and accessibility for healthcare professionals and novices alike.</p>
        <!-- <p>Utilizing HTML, CSS, JavaScript for the front-end and powered by PHP and MySQL for robust back-end
            functionalities, our system prioritizes user security, ease-of-use, and efficient delivery management.
        </p> -->
    </div>

    <p>Our mission is to redefine logistics through innovation and reliability. We envision a future where drone
        delivery not only enhances operational efficiency but also reduces environmental impact, making deliveries
        faster and more sustainable.</p>


    <!-- Contact -->
    <div class="w3-container" id="contact" style="margin-top:75px;">
        <h1 class="w3-xxxlarge w3-text-red"><b>Contact.</b></h1>
        <hr style="width:50px;border:5px solid red" class="w3-round">
        <p>Fill out the form below, and let us know your
            feedback or inquiry. We're here to help!</p>
        <form action="" method="POST">
            <div class="w3-section">
                <label><b>Name</b></label>
                <input class="w3-input w3-border" type="text" name="name" required>
            </div>
            <div class="w3-section">
                <label><b>Email</b></label>
                <input class="w3-input w3-border" type="text" name="email" required>
            </div>
            <div class="w3-section">
                <label><b>Subject</b></label>
                <input class="w3-input w3-border" type="text" name="subject" required>
            </div>
            <div class="w3-section">
                <label><b>Message</b></label>
                <input class="w3-input w3-border" type="text" name="message" required>
            </div>
            <button type="submit" class="w3-button w3-block w3-padding-large w3-red w3-margin-bottom">Send
                Message</button>
        </form>
    </div>

</div>
<!-- End page content -->


<!-- Include Footer -->
<?php include("./footer.php"); ?>


<!-- Backend for contact form -->
<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $subject = $_POST['subject'];
    $message = $_POST['message'];

    // Insert data into your database
    $query = mysqli_query($connect, "INSERT INTO queries (name, email, subject, message) 
    VALUES ('$name', '$email', '$subject', '$message')");

    if ($query) {
        echo '<script>
                Swal.fire({
                    icon: "success",
                    title: "Message Sent Successfully!",
                    showConfirmButton: false,
                    timer: 1500
                });
             </script>';

             echo "<script> setTimeout(function(){ window.location.href = 'index.php#contact'; }, 1000); </script>";

    } else {
        echo '<script>
                Swal.fire({
                    icon: "error",
                    title: "Failed to send message.",
                    showConfirmButton: false,
                    timer: 1500
                });
             </script>';

             echo "<script> setTimeout(function(){ window.location.href = 'index.php#contact'; }, 1000); </script>";

    }

}
?>
<!-- Backend for contact form -->