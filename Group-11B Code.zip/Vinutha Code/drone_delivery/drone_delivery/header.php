<?php include("./DB/connection.php"); ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Drone Delivery Management</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
    body,
    h1,
    h2,
    h3,
    h4,
    h5 {
        font-family: "Poppins", sans-serif
    }

    body {
        font-size: 16px;
    }

    .w3-half img {
        margin-bottom: -6px;
        margin-top: 16px;
        opacity: 0.8;
        cursor: pointer
    }

    .w3-half img:hover {
        opacity: 1
    }

    /* CSS Styles for Notifications */
    .notification-container {
        margin-top: 20px;
    }

    .notification {
        border: 1px solid #ccc;
        border-radius: 5px;
        margin-bottom: 10px;
        padding: 10px;
        background-color: #f9f9f9;
    }

    .notification-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 5px;
        font-size: 18px;
        margin: 10px
    }

    .from {
        font-weight: bold;
        color: #333;
    }

    .date {
        color: #888;
        font-size: 0.9em;
    }

    .notification-content p {
        margin: 10px;
        color: #555;
        font-size: 18px;
    }

    .headtext {
        font-weight: bold;
        font-size: 30px;
        margin: 15px;
    }
    </style>
</head>

<body>

    <!-- Sidebar/menu -->
    <nav class="w3-sidebar w3-red w3-collapse w3-top w3-large w3-padding"
        style="z-index:3;width:260px;font-weight:bold;" id="mySidebar"><br>
        <a href="javascript:void(0)" onclick="w3_close()" class="w3-button w3-hide-large w3-display-topleft"
            style="width:100%;font-size:25px">Close Menu</a>

        <div class="w3-container text-center">
            <img src="./IMG/drone2.png" style="max-width:100px" class="img-fluid" alt="Description of the image">
            <h3 class="pb-3"><b>Drone Delivery<br>Management</b></h3>
        </div>
        <div class="w3-bar-block">
            <a href="index.php" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white mb-2"><i
                    class="fas fa-home"></i>
                Home</a>
            <a href="index.php#services" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white mb-2"><i
                    class="fas fa-info-circle"></i> About</a>
            <a href="index.php#contact" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white mb-2"><i
                    class="fas fa-envelope"></i> Contact</a>

            <?php 
            session_start();
            $userID = 0;

            if(isset($_SESSION['start']) && $_SESSION['start'] == true) {
                $userID = $_SESSION['user_id'];

             ?>
            <a href="quote.php" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white mb-2"><i
                    class="fas fa-file-alt"></i> Quote</a>
            <a href="myDelivery.php" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white mb-2"><i
                    class="fas fa-plane"></i> Delivery</a>
            <!-- <a href="history.php" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white mb-2"><i
                    class="fas fa-history"></i> History</a> -->
            <a href="profile.php" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white mb-2"><i
                    class="fas fa-user"></i> Profile</a>
            <a href="logout.php" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white mb-2"><i
                    class="fas fa-sign-out-alt"></i> Logout</a>
            <?php
            } else {
            ?>
            <a href="register.php" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white mb-2"><i
                    class="fas fa-user-plus"></i> Register</a>
            <a href="login.php" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white mb-2"><i
                    class="fas fa-sign-in-alt"></i> Login</a>
            <?php
            }
            ?>



        </div>
    </nav>

    <!-- Top menu on small screens -->
    <header class="w3-container w3-top w3-hide-large w3-red w3-xlarge w3-padding">
        <a href="javascript:void(0)" class="w3-button w3-red w3-margin-right" onclick="w3_open()">☰</a>
        <span>Drone Delivery Management</span>
    </header>

    <!-- Overlay effect when opening sidebar on small screens -->
    <div class="w3-overlay w3-hide-large" onclick="w3_close()" style="cursor:pointer" title="close side menu"
        id="myOverlay">
    </div>


    <!-- backend code for notification count -->
    <?php
    // execute queries
    $query = mysqli_query($connect, "SELECT * from notification WHERE `to` = '$userID' ORDER BY bell_id DESC");
    // store totals
    $count = mysqli_num_rows($query);
    ?>
    <!-- backend code for notification count -->

    <!-- notification button -->
    <div style="background:black;height:50px;">
        <button id="openModalBtn" class="btn btn-sm btn-warning" style="float:right;margin-right:20px;font-size: 20px;width: 70px;
    margin-top: 5px;padding: 9px;"><i class="fas fa-bell" style="display:block"> <?=$count ?? 0?>
        </button>
    </div>

    <!-- The Modal -->
    <div id="myModal" class="w3-modal">
        <div class="w3-modal-content" style="float: right;
    margin-right: 50px;">
            <div class="w3-container">
                <span onclick="document.getElementById('myModal').style.display='none'"
                    class="w3-button w3-display-topright" style="font-size:35px">&times;</span>
                <p class="headtext">Your Notifications:</p>
                <div class="notification-container">
                    <?php
                while ($row = mysqli_fetch_assoc($query)) {
                    // Display content for each notification
                    $from = $row['from'];
                    $message = $row['message'];
                    $date = $row['date']; 

                    // Styling and displaying the notification content
                    ?>
                    <div class="notification">
                        <div class="notification-header">
                            <span class="from"><b>From:</b> <?=$from?></span>
                            <span class="date"><?=$date?></span>
                        </div>
                        <div class="notification-content">
                            <p><?=$message?></p>
                        </div>
                    </div>
                    <?php
                    }
                    ?>
                </div>

            </div>
        </div>
    </div>

    <script>
    // JavaScript to handle button click and open the modal
    document.getElementById("openModalBtn").onclick = function() {
        document.getElementById('myModal').style.display = 'block';
    }
    </script>