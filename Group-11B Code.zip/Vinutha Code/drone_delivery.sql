-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 24, 2023 at 12:43 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `drone_delivery`
--

-- --------------------------------------------------------

--
-- Table structure for table `deliveries`
--

CREATE TABLE `deliveries` (
  `delivery_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `quote_id` int(11) NOT NULL,
  `order_id` varchar(50) NOT NULL,
  `total_amt` double NOT NULL,
  `delivery_status` varchar(50) NOT NULL DEFAULT 'Pending',
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `deliveries`
--

INSERT INTO `deliveries` (`delivery_id`, `user_id`, `company_id`, `quote_id`, `order_id`, `total_amt`, `delivery_status`, `date`) VALUES
(8, 2, 6, 5, 'ORD_81904', 200, 'Delivered', '2023-11-24 08:19:24'),
(9, 2, 6, 4, 'ORD_69947', 300, 'Rejected', '2023-11-24 08:19:26'),
(10, 3, 6, 7, 'ORD_87690', 250, 'Delivered', '2023-11-24 11:43:07'),
(11, 4, 6, 8, 'ORD_94485', 230, 'Delivered', '2023-11-24 08:56:33'),
(12, 8, 9, 9, 'ORD_69074', 430, 'Delivered', '2023-11-24 11:06:57');

-- --------------------------------------------------------

--
-- Table structure for table `drones`
--

CREATE TABLE `drones` (
  `drone_id` int(11) NOT NULL,
  `drone_name` varchar(50) DEFAULT NULL,
  `drone_model` varchar(50) DEFAULT NULL,
  `weight` varchar(50) DEFAULT NULL,
  `max_payload` varchar(50) DEFAULT NULL,
  `registration_number` varchar(30) DEFAULT NULL,
  `battery_life` varchar(50) DEFAULT NULL,
  `flight_logs` text DEFAULT NULL,
  `company_id` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `drones`
--

INSERT INTO `drones` (`drone_id`, `drone_name`, `drone_model`, `weight`, `max_payload`, `registration_number`, `battery_life`, `flight_logs`, `company_id`, `date`) VALUES
(2, 'DMR FLyer', 'DM123', '120 KG', '200 KG', '12345DRX', '8 hours', '123:0987', 6, '2023-11-24 10:50:23'),
(3, 'DMR FLyer', 'DM123', '80 KG', '140 KG', '12345DRX', '10 hours', '123:0987', 6, '2023-11-24 10:50:36'),
(4, 'DMR FLyer', 'DM123', '120 KG', '200 KG', '12345DRX', '8 hours', '123:0987', 9, '2023-11-24 11:06:09');

-- --------------------------------------------------------

--
-- Table structure for table `feedbacks`
--

CREATE TABLE `feedbacks` (
  `feedback_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `order_id` varchar(50) NOT NULL,
  `star_rating` varchar(50) NOT NULL,
  `feedback_text` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `feedbacks`
--

INSERT INTO `feedbacks` (`feedback_id`, `user_id`, `order_id`, `star_rating`, `feedback_text`) VALUES
(7, 2, 'ORD_81904', '5', 'Good Good'),
(8, 4, 'ORD_94485', '4', 'Nice delivery'),
(9, 8, 'ORD_69074', '4', 'delivery was on point');

-- --------------------------------------------------------

--
-- Table structure for table `notification`
--

CREATE TABLE `notification` (
  `bell_id` int(11) NOT NULL,
  `from` varchar(100) NOT NULL,
  `to` int(11) NOT NULL,
  `message` varchar(200) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notification`
--

INSERT INTO `notification` (`bell_id`, `from`, `to`, `message`, `date`) VALUES
(3, 'Admin', 4, 'Your quote has been generated, please check.', '2023-11-24 06:30:30'),
(5, 'Admin', 4, '`The status for the Order Id: ORD_94485 has been Approved`', '2023-11-24 07:14:35'),
(19, 'Company', 4, 'The status for the Order Id: ORD_94485 has been Ready-To-Ship', '2023-11-24 08:55:50'),
(20, 'Company', 4, 'The status for the Order Id: ORD_94485 has been Delivered', '2023-11-24 08:56:33'),
(21, 'Admin', 8, 'Your quote has been generated, please check.', '2023-11-24 11:04:12'),
(22, 'Admin', 8, 'The status for the Order Id: ORD_69074 has been Approved', '2023-11-24 11:05:01'),
(23, 'Company', 8, 'The status for the Order Id: ORD_69074 has been updated to: Ready-To-Ship', '2023-11-24 11:06:25'),
(24, 'Company', 8, 'The status for the Order Id: ORD_69074 has been updated to: Delivered', '2023-11-24 11:06:57'),
(25, 'Company', 3, 'The status for the Order Id: ORD_87690 has been updated to: Ready-To-Ship', '2023-11-24 11:19:51'),
(26, 'Company', 3, 'The status for the Order Id: ORD_87690 has been updated to: Shipped', '2023-11-24 11:37:52'),
(27, 'Company', 3, 'The status for the Order Id: ORD_87690 has been updated to: Delivered', '2023-11-24 11:43:07');

-- --------------------------------------------------------

--
-- Table structure for table `queries`
--

CREATE TABLE `queries` (
  `query_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `queries`
--

INSERT INTO `queries` (`query_id`, `name`, `email`, `subject`, `message`, `date`) VALUES
(15, 'Test One', 'test1@gmail.com', 'testing', 'testing purpose', '2023-11-23 11:32:12'),
(17, 'User Three', 'user3@gmail.com', 'testing', 'testing purpose', '2023-11-24 06:21:17'),
(18, 'John wick', 'user2@gmail.com', 'Test', 'Testing time', '2023-11-24 11:00:34');

-- --------------------------------------------------------

--
-- Table structure for table `quotes`
--

CREATE TABLE `quotes` (
  `quote_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `image` varchar(100) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `user_number` int(10) NOT NULL,
  `delivery_type` varchar(255) DEFAULT NULL,
  `delivery_address` varchar(100) NOT NULL,
  `zip_code` varchar(50) NOT NULL,
  `other_service` varchar(100) NOT NULL,
  `package_size` varchar(50) NOT NULL,
  `package_weight` varchar(50) NOT NULL,
  `delivery_price` double NOT NULL,
  `estimated_time` varchar(50) NOT NULL,
  `latitude` varchar(20) NOT NULL,
  `longitude` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `quotes`
--

INSERT INTO `quotes` (`quote_id`, `user_id`, `image`, `user_name`, `user_number`, `delivery_type`, `delivery_address`, `zip_code`, `other_service`, `package_size`, `package_weight`, `delivery_price`, `estimated_time`, `latitude`, `longitude`) VALUES
(4, 2, 'Upload/activity-diagram-for-banking-system-UML-650x665.png', 'User One', 12345, 'normal', 'UK HP Hospital ', 'UK00324', 'Extra sirings', '3x3', '34KG', 300, '3 hours', '51.506980', '0.069530'),
(5, 2, 'Upload/image (4).png', 'User One', 987654321, 'normal', 'UK HP Hospital ', 'UK00324', 'Extra sirings', '4x4', '33KG', 200, '4 hours', '51.506980', '0.069530'),
(7, 3, 'Upload/image (2).png', 'User Two', 12345, 'overnight', 'UK HP Hospital ', 'UK00324', 'Extra sirings', '5x5', '130 KG', 250, '7 hours', '51.506988', '0.069533'),
(8, 4, 'Upload/download (2).jfif', 'User Three', 1234556789, 'overnight', 'UK HP Hospital ', 'UK00324', 'Extra siring', '6x5', '120 KG', 230, '7 hours', '51.506980', '0.069530'),
(9, 8, 'Upload/download (2).jfif', 'User Five', 1234579098, 'overnight', 'UK HP Hospital ', 'UK00324', 'Extra sirings', '5x5', '130 KG', 430, '7 hours', '51.506988', '0.069533');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `number` int(10) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `user_type` varchar(50) NOT NULL DEFAULT 'User',
  `date` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` varchar(20) NOT NULL DEFAULT 'Active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `name`, `number`, `email`, `password`, `user_type`, `date`, `status`) VALUES
(1, 'Adminstrator', 0, 'admin@gmail.com', 'admin', 'Admin', '2023-11-22 07:32:19', 'Active'),
(2, 'User One', 987654321, 'user1@gmail.com', '12345', 'User', '2023-11-22 07:32:42', 'Active'),
(3, 'User Two', 12345, 'user2@gmail.com', '12345', 'User', '2023-11-22 07:33:07', 'Active'),
(4, 'User Three', 1234556789, 'user3@gmail.com', '12345', 'User', '2023-11-24 06:20:24', 'Active'),
(5, 'User Four', 987654321, 'user4@gmail.com', '12345', 'User', '2023-11-24 06:20:50', 'Active'),
(6, 'Company One', 1234567890, 'company1@gmail.com', '12345', 'Company', '2023-11-24 08:19:04', 'Active'),
(7, 'Company Two', 123456789, 'company2@gmail.com', '12345', 'Company', '2023-11-24 08:22:36', 'Active'),
(8, 'John Wick', 2147483647, 'user5@gmail.com', '12345', 'User', '2023-11-24 11:01:31', 'Active'),
(9, 'Company Three', 1235508996, 'company3@gmail.com', '12345', 'Company', '2023-11-24 11:03:49', 'Active');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `deliveries`
--
ALTER TABLE `deliveries`
  ADD PRIMARY KEY (`delivery_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `quote_id` (`quote_id`),
  ADD KEY `company_id` (`company_id`);

--
-- Indexes for table `drones`
--
ALTER TABLE `drones`
  ADD PRIMARY KEY (`drone_id`),
  ADD KEY `company_id` (`company_id`);

--
-- Indexes for table `feedbacks`
--
ALTER TABLE `feedbacks`
  ADD PRIMARY KEY (`feedback_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `notification`
--
ALTER TABLE `notification`
  ADD PRIMARY KEY (`bell_id`),
  ADD KEY `to` (`to`);

--
-- Indexes for table `queries`
--
ALTER TABLE `queries`
  ADD PRIMARY KEY (`query_id`);

--
-- Indexes for table `quotes`
--
ALTER TABLE `quotes`
  ADD PRIMARY KEY (`quote_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `deliveries`
--
ALTER TABLE `deliveries`
  MODIFY `delivery_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `drones`
--
ALTER TABLE `drones`
  MODIFY `drone_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `feedbacks`
--
ALTER TABLE `feedbacks`
  MODIFY `feedback_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `notification`
--
ALTER TABLE `notification`
  MODIFY `bell_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `queries`
--
ALTER TABLE `queries`
  MODIFY `query_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `quotes`
--
ALTER TABLE `quotes`
  MODIFY `quote_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `deliveries`
--
ALTER TABLE `deliveries`
  ADD CONSTRAINT `deliveries_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `deliveries_ibfk_2` FOREIGN KEY (`quote_id`) REFERENCES `quotes` (`quote_id`);

--
-- Constraints for table `drones`
--
ALTER TABLE `drones`
  ADD CONSTRAINT `drones_ibfk_1` FOREIGN KEY (`company_id`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `feedbacks`
--
ALTER TABLE `feedbacks`
  ADD CONSTRAINT `feedbacks_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `notification`
--
ALTER TABLE `notification`
  ADD CONSTRAINT `notification_ibfk_1` FOREIGN KEY (`to`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `quotes`
--
ALTER TABLE `quotes`
  ADD CONSTRAINT `quotes_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
